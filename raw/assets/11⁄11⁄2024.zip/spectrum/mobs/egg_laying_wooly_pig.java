// Made with Blockbench 4.5.0
// Exported for Minecraft version 1.17+ for Yarn
// Paste this class into your mod and generate all required imports
public class egg_laying_wooly_pig extends EntityModel<Entity> {
	private final ModelPart torso;
	private final ModelPart head;
	private final ModelPart ear_r1;
	private final ModelPart ear_r2;
	private final ModelPart left_foreleg;
	private final ModelPart right_foreleg;
	private final ModelPart left_backleg;
	private final ModelPart right_backleg;
	private final ModelPart tail;
	public egg_laying_wooly_pig(ModelPart root) {
		this.torso = root.getChild("torso");
	}
	public static TexturedModelData getTexturedModelData() {
		ModelData modelData = new ModelData();
		ModelPartData modelPartData = modelData.getRoot();
		ModelPartData torso = modelPartData.addChild("torso", ModelPartBuilder.create().uv(42, 47).cuboid(-5.0F, -14.0F, -7.0F, 10.0F, 8.0F, 14.0F, new Dilation(0.0F))
		.uv(0, 32).cuboid(-5.5F, -14.5F, -8.5F, 11.0F, 12.0F, 17.0F, new Dilation(0.0F))
		.uv(0, 0).cuboid(-6.5F, -15.5F, -9.5F, 13.0F, 13.0F, 19.0F, new Dilation(0.0F)), ModelTransform.pivot(0.0F, 24.0F, 0.0F));

		ModelPartData head = torso.addChild("head", ModelPartBuilder.create().uv(56, 24).cuboid(-4.0F, -6.0F, -6.0F, 8.0F, 8.0F, 8.0F, new Dilation(0.0F))
		.uv(0, 44).cuboid(-2.5F, -2.0F, -7.0F, 5.0F, 3.0F, 1.0F, new Dilation(0.0F))
		.uv(45, 0).cuboid(-5.02F, -7.0F, -7.0F, 10.0F, 7.0F, 10.0F, new Dilation(0.0F)), ModelTransform.pivot(0.0F, -13.0F, -7.0F));

		ModelPartData ear_r1 = head.addChild("ear_r1", ModelPartBuilder.create().uv(0, 0).cuboid(7.0964F, -13.0939F, -10.5F, 3.0F, 7.0F, 5.0F, new Dilation(0.0F)), ModelTransform.of(0.0F, 10.0F, 6.0F, 0.0F, 0.0F, -0.3927F));

		ModelPartData ear_r2 = head.addChild("ear_r2", ModelPartBuilder.create().uv(0, 32).cuboid(-10.0964F, -13.0939F, -10.5F, 3.0F, 7.0F, 5.0F, new Dilation(0.0F)), ModelTransform.of(0.0F, 10.0F, 6.0F, 0.0F, 0.0F, 0.3927F));

		ModelPartData left_foreleg = torso.addChild("left_foreleg", ModelPartBuilder.create().uv(54, 69).cuboid(-2.0F, 0.0F, -2.0F, 4.0F, 6.0F, 4.0F, new Dilation(0.0F)), ModelTransform.pivot(-3.0F, -6.0F, -4.0F));

		ModelPartData right_foreleg = torso.addChild("right_foreleg", ModelPartBuilder.create().uv(38, 69).cuboid(-2.0F, 0.0F, -2.0F, 4.0F, 6.0F, 4.0F, new Dilation(0.0F)), ModelTransform.pivot(3.0F, -6.0F, -4.0F));

		ModelPartData left_backleg = torso.addChild("left_backleg", ModelPartBuilder.create().uv(0, 61).cuboid(-3.0F, -2.0F, -3.0F, 5.0F, 6.0F, 6.0F, new Dilation(0.0F))
		.uv(61, 40).cuboid(-3.0F, 4.0F, 0.0F, 3.0F, 4.0F, 3.0F, new Dilation(0.0F)), ModelTransform.pivot(-3.0F, -8.0F, 5.0F));

		ModelPartData right_backleg = torso.addChild("right_backleg", ModelPartBuilder.create().uv(39, 34).cuboid(-2.0F, -2.0F, -3.0F, 5.0F, 6.0F, 6.0F, new Dilation(0.0F))
		.uv(0, 12).cuboid(0.0F, 4.0F, 0.0F, 3.0F, 4.0F, 3.0F, new Dilation(0.0F)), ModelTransform.pivot(3.0F, -8.0F, 5.0F));

		ModelPartData tail = torso.addChild("tail", ModelPartBuilder.create().uv(22, 61).cuboid(-2.5F, -4.0F, -0.5F, 5.0F, 5.0F, 5.0F, new Dilation(0.0F)), ModelTransform.pivot(0.0F, -13.0F, 6.5F));
		return TexturedModelData.of(modelData, 128, 128);
	}
	@Override
	public void setAngles(Entity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
	}
	@Override
	public void render(MatrixStack matrices, VertexConsumer vertexConsumer, int light, int overlay, float red, float green, float blue, float alpha) {
		torso.render(matrices, vertexConsumer, light, overlay, red, green, blue, alpha);
	}
}